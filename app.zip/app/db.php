<?php
//database_connection.php

$connect = new PDO('mysql:host=eu-cdbr-west-01.cleardb.com;dbname=heroku_705a32a5ae1bbea', 'b4e2418e59d7ed', 'b46998fc');
session_start();

?>