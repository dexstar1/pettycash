<?php

$username = 'b4e2418e59d7ed';
$password = 'b46998fc';
$connection = new PDO( 'mysql:host=heroku_705a32a5ae1bbea?reconnect=true;dbname=eu-cdbr-west-01.cleardb.com', 
$username, $password );

?>
